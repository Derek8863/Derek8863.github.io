# Go 示例执行记录

执行日期：2026-11-13。环境：`go version go1.18.3 windows/amd64`。

本文的两组 Go 代码和测试已通过本地命令运行；没有开展完整 Codex 自动修复或性能评测。测试直接调用 HTTP handler，没有启动监听端口，也没有连接数据库。

分别进入 `before/` 和 `after/`，执行相同命令：

```text
go test -v -count=1 ./...
```

## 修复前

命令退出码：1，符合预期。

```text
=== RUN   TestOrdersMissingUserID
    orders_test.go:14: expected 400, got 500
--- FAIL: TestOrdersMissingUserID (0.00s)
=== RUN   TestOrdersWithUserID
--- PASS: TestOrdersWithUserID (0.00s)
FAIL
FAIL	example.com/orders	0.065s
FAIL
```

## 修复后

命令退出码：0，符合预期。

```text
=== RUN   TestOrdersMissingUserID
--- PASS: TestOrdersMissingUserID (0.00s)
=== RUN   TestOrdersWithUserID
--- PASS: TestOrdersWithUserID (0.00s)
PASS
ok  	example.com/orders	0.075s
```

测试覆盖缺少参数时的 400 和有参数时的 200；不覆盖鉴权、真实订单查询、响应体或并发行为。输出中的耗时只用于保留原始记录，不用于性能比较。
