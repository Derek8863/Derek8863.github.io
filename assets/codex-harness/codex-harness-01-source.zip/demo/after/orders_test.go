package orders

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestOrdersMissingUserID(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/orders", nil)
	rec := httptest.NewRecorder()
	Orders(rec, req)
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d", rec.Code)
	}
}

func TestOrdersWithUserID(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/orders?user_id=42", nil)
	rec := httptest.NewRecorder()
	Orders(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", rec.Code)
	}
}
