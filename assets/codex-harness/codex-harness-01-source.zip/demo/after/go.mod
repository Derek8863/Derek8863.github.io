module example.com/orders

go 1.18
