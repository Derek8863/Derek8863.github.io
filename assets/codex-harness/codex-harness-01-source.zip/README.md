# 深入浅出 Codex Harness

第一篇：[模型说要执行命令，然后呢？](01-model-to-execution.md)

本系列从一次命令调用开始，解释模型、工具与执行环境如何配合。首篇提供 Markdown 正文、两张 SVG 配图、独立 HTML 阅读版，以及 Go 测试示例。

- `01-model-to-execution.md`：正文与固定版本源码链接。
- `assets/`：文章配图。
- `demo/before/`：修复前示例，测试预期失败。
- `demo/after/`：修复后示例，测试预期通过。
- `demo/verification.md`：实际执行记录及验证范围。
- `build_article.py`：生成独立阅读版与配套 ZIP；优先使用 `markdown-it-py`，也支持本文使用的 Markdown 子集，无需额外安装。

HTML 阅读版内嵌两张配图，并提供配套材料下载，不依赖外部字体或脚本。Markdown 发布时需一并保留 `assets/` 的相对路径。

源码基准：`openai/codex@69231e119bfca0b14453515e97d99688ce1c47c9`；资料核对日期为 2026-11-13。
