from pathlib import Path
import base64
import html
import re
import zipfile


def render_markdown(text):
    # Standalone fallback covers the Markdown constructs used in this article.
    try:
        from markdown_it import MarkdownIt
        return MarkdownIt("commonmark", {"html": False}).enable("table").render(text)
    except ImportError:
        pass

    def inline(value):
        saved = []
        def keep(fragment):
            saved.append(fragment)
            return f"@@INLINE{len(saved)-1}@@"
        value = re.sub(r"`([^`]+)`", lambda m: keep("<code>" + html.escape(m[1]) + "</code>"), value)
        value = html.escape(value, quote=False)
        value = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', lambda m: keep(f'<img src="{html.escape(m[2], quote=True)}" alt="{html.escape(m[1], quote=True)}">'), value)
        value = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', value)
        value = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', value)
        for i, fragment in reversed(list(enumerate(saved))):
            value = value.replace(f"@@INLINE{i}@@", fragment)
        return value

    lines = text.splitlines()
    blocks = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        if line.startswith("```"):
            lang = line[3:]
            code = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                code.append(lines[i])
                i += 1
            blocks.append(f'<pre><code class="language-{lang}">' + html.escape("\n".join(code)) + '</code></pre>')
            i += 1
        elif line.startswith("## "):
            blocks.append("<h2>" + inline(line[3:]) + "</h2>")
            i += 1
        elif line.startswith("| "):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                row = [cell.strip() for cell in lines[i].strip("|").split("|")]
                if not all(re.fullmatch(r"[-: ]+", c) for c in row):
                    rows.append(row)
                i += 1
            rendered = []
            for index, row in enumerate(rows):
                tag = "th" if index == 0 else "td"
                rendered.append("<tr>" + "".join(f"<{tag}>" + inline(c) + f"</{tag}>" for c in row) + "</tr>")
            blocks.append("<table>" + "".join(rendered) + "</table>")
        elif line.startswith("- "):
            items = []
            while i < len(lines) and lines[i].startswith("- "):
                items.append("<li>" + inline(lines[i][2:]) + "</li>")
                i += 1
            blocks.append("<ul>" + "".join(items) + "</ul>")
        elif line.startswith("> "):
            blocks.append("<blockquote><p>" + inline(line[2:]) + "</p></blockquote>")
            i += 1
        else:
            paragraph = [line]
            i += 1
            while i < len(lines) and lines[i].strip():
                paragraph.append(lines[i])
                i += 1
            blocks.append("<p>" + inline("\n".join(paragraph)) + "</p>")
    return "\n".join(blocks)


ROOT = Path(__file__).resolve().parent
source = ROOT / "01-model-to-execution.md"
text = source.read_text(encoding="utf-8")
front, body = text.split("---", 2)[1:]
title = re.search(r'^title: "(.*)"$', front, re.M).group(1)
content = render_markdown(body.strip())


def inline_image(match):
    relative, alt = match.groups()
    path = ROOT / relative
    if path.suffix != ".svg" or not path.is_file():
        raise ValueError(f"Missing image: {relative}")
    payload = base64.b64encode(path.read_bytes()).decode("ascii")
    return f'<figure><img src="data:image/svg+xml;base64,{payload}" alt="{alt}"></figure>'


content = re.sub(r'<p><img src="([^"]+)" alt="([^"]*)"\s*/?></p>', inline_image, content)
content = re.sub(r'<p>(图 [12]：.*?)</p>', r'<p class="caption">\1</p>', content)
content = content.replace("<table>", '<div class="table-scroll"><table>').replace("</table>", "</table></div>")
sections = []


def heading(match):
    name = match.group(1)
    anchor = f"section-{len(sections) + 1}"
    sections.append((anchor, name))
    return f'<h2 id="{anchor}">{name}</h2>'


content = re.sub(r"<h2>(.*?)</h2>", heading, content)
zip_path = ROOT / "codex-harness-01-source.zip"
files = [source, ROOT / "README.md", ROOT / "build_article.py"]
files += sorted((ROOT / "assets").glob("*.svg"))
files += sorted(p for p in (ROOT / "demo").rglob("*") if p.is_file())
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        archive.write(path, path.relative_to(ROOT).as_posix())
zip_data = base64.b64encode(zip_path.read_bytes()).decode("ascii")
toc = "".join(f'<a href="#{anchor}">{name}</a>' for anchor, name in sections)
css = """
:root{--ink:#20343b;--muted:#62757b;--accent:#217b77;--line:#dbe6e7;--paper:#fff}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#f4f7f7;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;font-size:17px;line-height:1.95}
.top{height:6px;background:var(--accent)}.wrap{max-width:1060px;margin:0 auto;padding:60px 42px 80px}.series{color:var(--accent);font-size:14px;letter-spacing:.14em;font-weight:700}.hero{padding:0 10px 34px}h1{font-size:39px;line-height:1.4;letter-spacing:-.035em;margin:18px 0 20px;max-width:850px}.dek{font-size:19px;color:var(--muted);max-width:780px}.meta{font-size:13px;color:var(--muted)}
.download{display:inline-block;border:1px solid #b7d2d0;border-radius:7px;padding:7px 14px;margin-top:20px;font-size:14px;background:#edf6f4;text-decoration:none}a{color:var(--accent);text-decoration-thickness:1px;text-underline-offset:3px;overflow-wrap:anywhere}
main{background:var(--paper);padding:42px 54px;border:1px solid var(--line);border-radius:14px}p{margin:20px 0}h2{font-size:26px;line-height:1.5;margin:48px 0 20px;scroll-margin-top:24px;padding-top:5px}strong{font-weight:650}blockquote{margin:24px 0;padding:4px 22px;border-left:4px solid var(--accent);background:#f0f7f6;border-radius:0 8px 8px 0}blockquote p{margin:12px 0}
code{font-family:Consolas,"SFMono-Regular",monospace;font-size:.88em;background:#eff3f4;padding:2px 5px;border-radius:4px;overflow-wrap:anywhere}pre{padding:22px 24px;background:#132c34;border-radius:10px;color:#e3eeee;overflow-x:auto;line-height:1.65;font-size:14px}pre code{background:none;color:inherit;padding:0;font-size:1em;overflow-wrap:normal}figure{margin:32px -20px 10px}figure img{display:block;width:100%;height:auto}.caption{font-size:13px;color:var(--muted);line-height:1.75;margin-top:10px}
.table-scroll{overflow-x:auto;margin:24px 0}table{border-collapse:collapse;width:100%;font-size:14px;line-height:1.75}th,td{text-align:left;padding:13px 14px;border-bottom:1px solid var(--line);vertical-align:top}th{background:#edf4f4;font-weight:650}td:first-child{min-width:135px}td code{overflow-wrap:anywhere}ul{padding-left:24px;font-size:15px}li{padding:4px 0}
details{border:1px solid var(--line);padding:12px 20px;background:#f8faf9;border-radius:8px;margin-bottom:30px;font-size:15px}summary{cursor:pointer;color:var(--accent);font-weight:600}nav{display:grid;grid-template-columns:1fr 1fr;gap:7px 20px;padding:16px 0 4px}nav a{text-decoration:none;font-size:14px}.foot{font-size:13px;color:var(--muted);text-align:center;padding:28px 0 0}
@media(max-width:650px){body{font-size:16px;line-height:1.9}.wrap{padding:30px 14px 45px}.hero{padding:0 7px 25px}h1{font-size:29px}.dek{font-size:17px}main{padding:22px 19px;border-radius:10px}h2{font-size:22px;margin-top:38px}figure{margin:25px -10px 10px}pre{padding:16px;font-size:12px}nav{grid-template-columns:1fr}th,td{padding:10px;font-size:13px}blockquote{padding:3px 15px}}
@media print{body{background:#fff}.wrap{padding:0}main{border:0;padding:15px 0}.download,details{display:none}pre{white-space:pre-wrap}h2{break-after:avoid}figure,table,pre{break-inside:avoid}}
"""
document = f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title><style>{css}</style></head>
<body><div class="top"></div><div class="wrap"><header class="hero"><div class="series">深入浅出 CODEX HARNESS · 01</div><h1>模型说要执行命令，<br>然后呢？</h1><p class="dek">跟着一次 Go 接口修复，看一份模型输出如何变成真实执行，再成为下一次判断的依据。</p><div class="meta">资料核对：2026-11-13 · 阅读版整理：2026-11-16 · 含两张流程图与可复现示例</div><a class="download" download="codex-harness-01-source.zip" href="data:application/zip;base64,{zip_data}">下载配套 Markdown、配图与 Go 示例</a></header>
<main><details><summary>本文目录</summary><nav>{toc}</nav></details>{content}</main><footer class="foot">深入浅出 Codex Harness · 第一篇</footer></div></body></html>'''
output = ROOT / "01-model-to-execution.html"
output.write_text(document, encoding="utf-8")
assert document.count('data:image/svg+xml;base64,') == 2
assert len(sections) == 8
assert '<script' not in document
print(f"HTML: {output} ({output.stat().st_size} bytes)")
print(f"ZIP: {zip_path} ({zip_path.stat().st_size} bytes)")
